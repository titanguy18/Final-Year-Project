
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Name</td>
                    <td>Description</td>
                    <td>Price</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $informations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($information->id); ?></td>
                    <td><?php echo e($information->name); ?></td>
                    <td><?php echo e($information->description); ?></td>
                    <td><?php echo e($information->price); ?></td>
                    <td><a href="<?php echo e(route('deleteInfo', ['id' => $information->id])); ?>" class="btn btn-danger btn-xs" onClick="return confirm('Are You Sure To Delete?')">Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="col-sm-2">&nbsp;</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Sem 4\Web-Based System\Test\Test_D210082B\resources\views/viewInfo.blade.php ENDPATH**/ ?>