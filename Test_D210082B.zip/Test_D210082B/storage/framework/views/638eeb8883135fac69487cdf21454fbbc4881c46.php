
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <form action="<?php echo e(route('addInfo')); ?>" method="post" enctype="multipart/form-data"><br><br> <?php echo csrf_field(); ?>
            <h3>Room Information</h3><br>
            <div class="row">
            <label>ID: <input type="text" name="ID"></label>&nbsp;
            <label>Name: <input type="text" name="Name"></label>&nbsp;
            <label>Description: <input type="text" name="Description"></label>&nbsp;
            <label>Price: <input type="text" name="Price"></label><br><br>
            <button type="submit" class="btn btn-info" style="width:70px;">Insert</button><br><br>
            </div>
        </form>
    </div>
    <div class="col-sm-2">&nbsp;</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Sem 4\Web-Based System\Test\Test_D210082B\resources\views/addInfo.blade.php ENDPATH**/ ?>