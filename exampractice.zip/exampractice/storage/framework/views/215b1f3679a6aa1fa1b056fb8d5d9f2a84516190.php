<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td style="color:white">ID</td>
                    <td style="color:white">Car Name</td>
                    <td style="color:white">Description</td>
                    <td style="color:white">Price</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="color:white"><?php echo e($car->id); ?></td>
                    <td style="color:white"><?php echo e($car->car); ?></td>
                    <td style="color:white"><?php echo e($car->description); ?></td>
                    <td style="color:white"><?php echo e($car->price); ?></td>

                    <td><a href ="<?php echo e(route('deleteCar',['id'=>$car->id])); ?>" class="btn btn-danger btn-xs" onClick="return confirm('Are you sure to delete?')">Delete</a>&nbsp;

                    <a href ="<?php echo e(route('editCar',['id'=>$car->id])); ?>" class="btn btn-info btn-xs">Edit</a>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
       
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/exampractice/resources/views/viewCar.blade.php ENDPATH**/ ?>