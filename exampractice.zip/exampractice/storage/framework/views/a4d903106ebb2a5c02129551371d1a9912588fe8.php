<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <h3 align="center" style="color:white">Edit Car</h3>
       
        <form action="<?php echo e(route('updateCar')); ?>" method="post" enctype="multipart/form-data"><br><br> <?php echo csrf_field(); ?>
        
            <h3 style="color:white">Product name</h3> 
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <!-- <button type="submit" class="btn btn-info">Update Product</button><br><br>  -->
            <input name="id" type="number" class="form-control" value="<?php echo e($car->id); ?>"><br>

            <input name="car" type="text" class="form-control" value="<?php echo e($car->car); ?>"><br>

            <input name="description" type="text" class="form-control" value="<?php echo e($car->description); ?>"><br>

            <input name="quantity" type="text" class="form-control" value="<?php echo e($car->quantity); ?>"><br>

            <input name="price" type="text" class="form-control" value="<?php echo e($car->price); ?>"><br>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <button type="submit" class="btn btn-info">Update Car</button><br><br>
        </form>
    </div>
    <div class="col-sm-2">&nbsp;</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/exampractice/resources/views/editCar.blade.php ENDPATH**/ ?>