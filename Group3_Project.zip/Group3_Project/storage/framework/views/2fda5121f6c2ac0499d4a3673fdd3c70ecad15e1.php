
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-2">&nbsp;</div>
    <div class="col-sm-8">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <td style="color:white">ID</td>
                    <td style="color:white">Car Name</td>
                    <td style="color:white">Description</td>
                    <td style="color:white">Price</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="color:white"><?php echo e($car->id); ?></td>
                    <td style="color:white"><?php echo e($car->car); ?></td>
                    <td style="color:white"><?php echo e($car->description); ?></td>
                    <td style="color:white"><?php echo e($car->price); ?></td>
                    
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="exportexcel"><button type = "export" class ="btn btn-info">Export Data</button><br><br>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP1\htdocs\Group_Project\resources\views/viewCar.blade.php ENDPATH**/ ?>