
 
<?php $__env->startSection('title'); ?>
    Car Data
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="container mt-3">
    <?php if($message = session('success')): ?>
    <div class="alert alert-success mx-1" role="alert">
        <?php echo e($message); ?>

    </div>
     <?php endif; ?>
    <h2 class=" text-center">Car Data</h2>
    <div class="mt-5">
         <a href="<?php echo e(route('car.export')); ?>" class="btn btn-primary">
             Export Data
        </a>
        <a href="<?php echo e(route('car.create')); ?>" class="btn btn-primary">
            Add Data
         </a>
    </div>
    <table class="table table-hover mt-5">
        <thead>
            <tr>
                <th>ID</th>
                <th>Car Namr</th>
                <th>Description</th>
                <th>Price</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($car->id); ?></td>
                      <td><?php echo e($car->car); ?></td>
                      <td><?php echo e($car->description); ?></td>
                      <td><?php echo e($car->price); ?></td>
                      <td><?php echo e($car->quantity); ?></td>
                  </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody> 
    </table> 
    <div class="mt-5">
        <?php echo e($cars->links()); ?>

    </div> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP1\htdocs\Group_Project\resources\views/car/index.blade.php ENDPATH**/ ?>